-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Oct 09, 2025 at 07:55 AM
-- Server version: 10.4.32-MariaDB
-- PHP Version: 8.1.25

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `fitness_club`
--

-- --------------------------------------------------------

--
-- Table structure for table `registrations`
--

CREATE TABLE `registrations` (
  `id` int(11) NOT NULL,
  `username` varchar(100) NOT NULL,
  `email` varchar(150) NOT NULL,
  `contact` varchar(15) NOT NULL,
  `password` varchar(255) NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `registrations`
--

INSERT INTO `registrations` (`id`, `username`, `email`, `contact`, `password`, `created_at`) VALUES
(1, 'riddhi pujara', 'ridhdhipujara@gmail.com', '1234567890', '$2y$10$3LkUVZUNBEWb1rRb60H3r.83Hj1EIfaWJ5Sn/xUoVB.NIgRSXkSuu', '2025-10-04 11:09:25'),
(3, 'shreya', 'shreya@gmail.com', '1212121212', '$2y$10$SXFcjxfVgss7CIwnimxCZeE2LcJXTACWxgSSR9.sCwbbDkxDOVhvm', '2025-10-04 12:03:32'),
(6, 'shreya', 'shreya123@gmail.com', '1212121212', '$2y$10$WY43FZT6H1K3BabCM0JcmegqPYnMA9YQPEK9XbBxKf1jyb1RONWHW', '2025-10-04 14:32:42'),
(8, 'rsp', 'rsp@gmail.com', '4561239870', '$2y$10$TteLmYOSRB7WUr6NqT.cGejPUYjMRP1Ox6bKkrA7hQ/EAbpFUt5nu', '2025-10-04 14:37:52'),
(9, 'Riddhi', 'riddhi123@gmail.com', '8989895232', '$2y$10$./2B.BORdVRAJWcYYqDUV.HgbZRq7dF4F5Aab81eLkKcuQof1Tzju', '2025-10-04 14:43:54'),
(10, 'Riddhi', 'abc@gmail.com', '8989895232', '$2y$10$yVAyLQl97f4RaLwvLtr0gu2.AXTVmivEXzB0VWvrraDJo9wlOngaK', '2025-10-06 07:32:02'),
(11, 'rsp', 'rsp12@gmail.com', '1234567890', '$2y$10$QJCoa5dqLDf12L91uWMCmuWR6bBHna9pLjMl1F3OfXBQtvD2su2eq', '2025-10-06 07:49:12');

-- --------------------------------------------------------

--
-- Table structure for table `residents`
--

CREATE TABLE `residents` (
  `id` int(11) NOT NULL,
  `fname` varchar(100) NOT NULL,
  `email` varchar(100) NOT NULL,
  `password` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `trainers`
--

CREATE TABLE `trainers` (
  `id` int(11) NOT NULL,
  `name` varchar(100) NOT NULL,
  `specialization` varchar(100) DEFAULT NULL,
  `experience` int(11) DEFAULT NULL,
  `certification` varchar(255) DEFAULT NULL,
  `photo_url` text DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `trainers`
--

INSERT INTO `trainers` (`id`, `name`, `specialization`, `experience`, `certification`, `photo_url`) VALUES
(1, 'Mr john', 'Yoga', 5, 'Certified Personal Trainer (NASM-CPT)', 'https://images.unsplash.com/photo-1682241367368-6387d5d4921a?q=80&w=687&auto=format&fit=crop&ixlib=rb-4.1.0&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D'),
(3, 'Alex Carter', 'Strength Training, Functional Fitness', 6, 'ACE Certified Personal Trainer', 'https://i.imgur.com/BJgMCKN.jpg');

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `id` int(11) NOT NULL,
  `username` varchar(100) NOT NULL,
  `email` varchar(100) NOT NULL,
  `contact` varchar(15) DEFAULT NULL,
  `password` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`id`, `username`, `email`, `contact`, `password`) VALUES
(1, 'rsp1234', 'rsp123@gmail.com', '1234567897', '$2y$10$3gnQXxXJxKXNzj6JYpvGa.3oqJsL6ag0fxrOgmgDF9kh98qQ5QDxq'),
(2, 'rsp', 'abcd@gmail.com', '1234567890', '$2y$10$RAWii/1XPx2xu0PdJ52stut2kJB2dZ39gzVD03Zrb5z/.1CNBJNLO');

-- --------------------------------------------------------

--
-- Table structure for table `workouts`
--

CREATE TABLE `workouts` (
  `id` int(11) NOT NULL,
  `workout_name` varchar(255) NOT NULL,
  `category` varchar(100) NOT NULL,
  `difficulty_level` varchar(50) NOT NULL,
  `duration` int(11) NOT NULL,
  `description` text DEFAULT NULL,
  `video_link` varchar(500) DEFAULT NULL,
  `image_urls` text DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `workouts`
--

INSERT INTO `workouts` (`id`, `workout_name`, `category`, `difficulty_level`, `duration`, `description`, `video_link`, `image_urls`, `created_at`) VALUES
(2, 'Full Body Strength Circuit', 'Strength Training', 'Intermediate', 45, 'A high-intensity full body strength training workout targeting major muscle groups using bodyweight and dumbbells. Great for building strength and endurance.', 'https://www.youtube.com/watch?v=UItWltVZZmE', 'https://example.com/images/fullbody1.jpg\r\n, https://example.com/images/fullbody2.jpg', '2025-10-06 19:19:31');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `registrations`
--
ALTER TABLE `registrations`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `email` (`email`);

--
-- Indexes for table `residents`
--
ALTER TABLE `residents`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `email` (`email`);

--
-- Indexes for table `trainers`
--
ALTER TABLE `trainers`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `email` (`email`);

--
-- Indexes for table `workouts`
--
ALTER TABLE `workouts`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `registrations`
--
ALTER TABLE `registrations`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=12;

--
-- AUTO_INCREMENT for table `residents`
--
ALTER TABLE `residents`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `trainers`
--
ALTER TABLE `trainers`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `workouts`
--
ALTER TABLE `workouts`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
