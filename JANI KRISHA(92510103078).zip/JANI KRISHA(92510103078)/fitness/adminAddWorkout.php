<?php
// adminAddWorkout.php

// Database connection
$host = "localhost";
$user = "root";
$password = "";
$database = "fitness_club";

$conn = new mysqli($host, $user, $password, $database);
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

$success_message = "";
$error_message = "";
$edit_mode = false;
$current_workout = null;

// Handle form submission for ADD and UPDATE
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if (isset($_POST['workout_id']) && !empty($_POST['workout_id'])) {
        // UPDATE operation
        $workout_id = (int)$_POST['workout_id'];
        $workout_name = $conn->real_escape_string($_POST['workout_name']);
        $category = $conn->real_escape_string($_POST['category']);
        $difficulty_level = $conn->real_escape_string($_POST['difficulty_level']);
        $duration = (int)$_POST['duration'];
        $description = $conn->real_escape_string($_POST['description']);
        $video_link = $conn->real_escape_string($_POST['video_link']);
        $image_urls = $conn->real_escape_string($_POST['image_urls']);
        
        $sql = "UPDATE workouts SET 
                workout_name = '$workout_name', 
                category = '$category', 
                difficulty_level = '$difficulty_level', 
                duration = $duration, 
                description = '$description', 
                video_link = '$video_link', 
                image_urls = '$image_urls' 
                WHERE id = $workout_id";
        
        if ($conn->query($sql) === TRUE) {
            $success_message = "Workout updated successfully!";
            $edit_mode = false;
        } else {
            $error_message = "Error updating workout: " . $conn->error;
        }
    } else {
        // ADD operation
        $workout_name = $conn->real_escape_string($_POST['workout_name']);
        $category = $conn->real_escape_string($_POST['category']);
        $difficulty_level = $conn->real_escape_string($_POST['difficulty_level']);
        $duration = (int)$_POST['duration'];
        $description = $conn->real_escape_string($_POST['description']);
        $video_link = $conn->real_escape_string($_POST['video_link']);
        $image_urls = $conn->real_escape_string($_POST['image_urls']);
        
        $sql = "INSERT INTO workouts (workout_name, category, difficulty_level, duration, description, video_link, image_urls) 
                VALUES ('$workout_name', '$category', '$difficulty_level', $duration, '$description', '$video_link', '$image_urls')";
        
        if ($conn->query($sql) === TRUE) {
            $success_message = "Workout added successfully!";
            $_POST = array(); // Clear form
        } else {
            $error_message = "Error adding workout: " . $conn->error;
        }
    }
}

// Handle EDIT request
if (isset($_GET['edit'])) {
    $workout_id = (int)$_GET['edit'];
    $sql = "SELECT * FROM workouts WHERE id = $workout_id";
    $result = $conn->query($sql);
    
    if ($result && $result->num_rows > 0) {
        $current_workout = $result->fetch_assoc();
        $edit_mode = true;
    }
}

// Handle DELETE request
if (isset($_GET['delete'])) {
    $workout_id = (int)$_GET['delete'];
    $sql = "DELETE FROM workouts WHERE id = $workout_id";
    
    if ($conn->query($sql) === TRUE) {
        $success_message = "Workout deleted successfully!";
    } else {
        $error_message = "Error deleting workout: " . $conn->error;
    }
}

// Fetch all workouts for management table
$sql = "SELECT * FROM workouts ORDER BY category, workout_name";
$workouts_result = $conn->query($sql);
$workouts = [];
if ($workouts_result && $workouts_result->num_rows > 0) {
    while ($row = $workouts_result->fetch_assoc()) {
        $workouts[] = $row;
    }
}

$conn->close();
?>

<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Manage Workouts - Admin Panel</title>
  <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@400;600&display=swap" rel="stylesheet">
  <style>
    * {
      margin: 0;
      padding: 0;
      box-sizing: border-box;
      font-family: 'Poppins', sans-serif;
    }
    body {
      background: #f4f7fa;
      color: #333;
    }

    /* Header */
    header {
      background: #2c3e50;
      padding: 15px 30px;
      color: #fff;
    }
    .header-container {
      max-width: 1200px;
      margin: 0 auto;
      display: flex;
      align-items: center;
      justify-content: space-between;
    }
    header h1 {
      font-size: 22px;
      font-weight: 600;
    }
    .main-nav a {
      color: #fff;
      margin-left: 20px;
      text-decoration: none;
      font-weight: 500;
      transition: 0.3s ease;
    }
    .main-nav a:hover {
      color: #00bcd4;
    }

    /* Messages */
    .message {
      padding: 15px;
      margin: 20px auto;
      max-width: 1200px;
      border-radius: 8px;
      text-align: center;
      font-weight: bold;
    }
    .success {
      background: #d4edda;
      color: #155724;
      border: 1px solid #c3e6cb;
    }
    .error {
      background: #f8d7da;
      color: #721c24;
      border: 1px solid #f5c6cb;
    }

    /* Main Container */
    .main-container {
      max-width: 1200px;
      margin: 20px auto;
      padding: 0 20px;
      display: grid;
      grid-template-columns: 1fr 1fr;
      gap: 30px;
    }

    /* Form Container */
    .form-container {
      background: #fff;
      padding: 30px;
      border-radius: 12px;
      box-shadow: 0 4px 15px rgba(0,0,0,0.1);
    }
    .form-container h2 {
      margin-bottom: 20px;
      text-align: center;
      color: #00bcd4;
    }

    label {
      display: block;
      margin-bottom: 8px;
      font-weight: 600;
    }
    input, textarea, select {
      width: 100%;
      padding: 10px;
      margin-bottom: 18px;
      border: 1px solid #ccc;
      border-radius: 8px;
      outline: none;
      transition: 0.3s ease;
    }
    input:focus, textarea:focus, select:focus {
      border-color: #00bcd4;
      box-shadow: 0 0 5px rgba(0,188,212,0.4);
    }

    textarea {
      min-height: 100px;
      resize: vertical;
    }

    .form-buttons {
      display: flex;
      gap: 10px;
    }
    button {
      flex: 1;
      padding: 12px;
      border: none;
      border-radius: 8px;
      cursor: pointer;
      transition: 0.3s ease;
      font-weight: 600;
    }
    .btn-primary {
      background: #00bcd4;
      color: #fff;
    }
    .btn-primary:hover {
      background: #0195a3;
    }
    .btn-secondary {
      background: #6c757d;
      color: #fff;
    }
    .btn-secondary:hover {
      background: #545b62;
    }

    .form-note {
      font-size: 12px;
      color: #666;
      margin-top: -10px;
      margin-bottom: 15px;
    }

    /* Workouts Table */
    .workouts-container {
      background: #fff;
      padding: 30px;
      border-radius: 12px;
      box-shadow: 0 4px 15px rgba(0,0,0,0.1);
    }
    .workouts-container h2 {
      margin-bottom: 20px;
      text-align: center;
      color: #00bcd4;
    }

    .workouts-table {
      width: 100%;
      border-collapse: collapse;
      margin-top: 20px;
    }
    .workouts-table th,
    .workouts-table td {
      padding: 12px;
      text-align: left;
      border-bottom: 1px solid #ddd;
    }
    .workouts-table th {
      background: #f8f9fa;
      font-weight: 600;
      color: #2c3e50;
    }
    .workouts-table tr:hover {
      background: #f8f9fa;
    }
    .action-buttons {
      display: flex;
      gap: 5px;
    }
    .btn-edit {
      background: #28a745;
      color: white;
      padding: 6px 12px;
      border: none;
      border-radius: 4px;
      cursor: pointer;
      text-decoration: none;
      font-size: 12px;
    }
    .btn-edit:hover {
      background: #218838;
    }
    .btn-delete {
      background: #dc3545;
      color: white;
      padding: 6px 12px;
      border: none;
      border-radius: 4px;
      cursor: pointer;
      text-decoration: none;
      font-size: 12px;
    }
    .btn-delete:hover {
      background: #c82333;
    }

    .difficulty-badge {
      padding: 3px 8px;
      border-radius: 12px;
      font-size: 0.8rem;
      font-weight: 600;
    }
    .difficulty-beginner {
      background: #d4edda;
      color: #155724;
    }
    .difficulty-intermediate {
      background: #fff3cd;
      color: #856404;
    }
    .difficulty-advanced {
      background: #f8d7da;
      color: #721c24;
    }

    .no-workouts {
      text-align: center;
      padding: 40px;
      color: #6c757d;
    }

    footer {
      background: #2c3e50;
      color: #fff;
      text-align: center;
      padding: 15px;
      margin-top: 40px;
    }
    .linkes a {
      color: #fff;
      margin: 0 10px;
      text-decoration: none;
    }
    .linkes a:hover {
      text-decoration: underline;
    }

    @media (max-width: 768px) {
      .main-container {
        grid-template-columns: 1fr;
      }
    }
  </style>
</head>
<body>

  <header>
    <div class="header-container">
        <h1>Fitness Club - Admin Panel</h1>
        <nav class="main-nav">
            <a href="adminAddWorkout.php" class="active">Manage Workouts</a>
            <a href="adminAddTrainer.php">Manage Trainers</a>
            <a href="home.html">Dashboard</a>
            <a href="aboutUs.html">Logout</a>
        </nav>
    </div>
  </header>

  <?php if ($success_message): ?>
    <div class="message success">
      <?= $success_message ?>
    </div>
  <?php endif; ?>

  <?php if ($error_message): ?>
    <div class="message error">
      <?= $error_message ?>
    </div>
  <?php endif; ?>

  <div class="main-container">
    <!-- Add/Edit Form -->
    <div class="form-container">
      <h2><?= $edit_mode ? 'Edit Workout' : 'Add New Workout' ?></h2>
      <form method="POST" action="">
        <?php if ($edit_mode): ?>
          <input type="hidden" name="workout_id" value="<?= $current_workout['id'] ?>">
        <?php endif; ?>
        
        <label for="workout_name">Workout Name</label>
        <input type="text" id="workout_name" name="workout_name" 
               value="<?= $edit_mode ? htmlspecialchars($current_workout['workout_name']) : (isset($_POST['workout_name']) ? htmlspecialchars($_POST['workout_name']) : '') ?>" 
               placeholder="Enter workout name" required>

        <label for="category">Category</label>
        <select id="category" name="category" required>
          <option value="">-- Select Category --</option>
          <option value="Strength Training" <?= (($edit_mode && $current_workout['category'] == 'Strength Training') || (isset($_POST['category']) && $_POST['category'] == 'Strength Training')) ? 'selected' : '' ?>>Strength Training</option>
          <option value="Cardio" <?= (($edit_mode && $current_workout['category'] == 'Cardio') || (isset($_POST['category']) && $_POST['category'] == 'Cardio')) ? 'selected' : '' ?>>Cardio</option>
          <option value="Yoga" <?= (($edit_mode && $current_workout['category'] == 'Yoga') || (isset($_POST['category']) && $_POST['category'] == 'Yoga')) ? 'selected' : '' ?>>Yoga</option>
          <option value="HIIT" <?= (($edit_mode && $current_workout['category'] == 'HIIT') || (isset($_POST['category']) && $_POST['category'] == 'HIIT')) ? 'selected' : '' ?>>HIIT</option>
          <option value="Pilates" <?= (($edit_mode && $current_workout['category'] == 'Pilates') || (isset($_POST['category']) && $_POST['category'] == 'Pilates')) ? 'selected' : '' ?>>Pilates</option>
          <option value="Flexibility" <?= (($edit_mode && $current_workout['category'] == 'Flexibility') || (isset($_POST['category']) && $_POST['category'] == 'Flexibility')) ? 'selected' : '' ?>>Flexibility</option>
        </select>

        <label for="difficulty_level">Difficulty Level</label>
        <select id="difficulty_level" name="difficulty_level" required>
          <option value="">-- Select Difficulty --</option>
          <option value="Beginner" <?= (($edit_mode && $current_workout['difficulty_level'] == 'Beginner') || (isset($_POST['difficulty_level']) && $_POST['difficulty_level'] == 'Beginner')) ? 'selected' : '' ?>>Beginner</option>
          <option value="Intermediate" <?= (($edit_mode && $current_workout['difficulty_level'] == 'Intermediate') || (isset($_POST['difficulty_level']) && $_POST['difficulty_level'] == 'Intermediate')) ? 'selected' : '' ?>>Intermediate</option>
          <option value="Advanced" <?= (($edit_mode && $current_workout['difficulty_level'] == 'Advanced') || (isset($_POST['difficulty_level']) && $_POST['difficulty_level'] == 'Advanced')) ? 'selected' : '' ?>>Advanced</option>
        </select>

        <label for="duration">Duration (minutes)</label>
        <input type="number" id="duration" name="duration" 
               value="<?= $edit_mode ? $current_workout['duration'] : (isset($_POST['duration']) ? htmlspecialchars($_POST['duration']) : '') ?>" 
               placeholder="Enter workout duration" required min="1">

        <label for="description">Description</label>
        <textarea id="description" name="description" placeholder="Enter workout description"><?= $edit_mode ? htmlspecialchars($current_workout['description']) : (isset($_POST['description']) ? htmlspecialchars($_POST['description']) : '') ?></textarea>

        <label for="video_link">Video Link (YouTube/Vimeo)</label>
        <input type="url" id="video_link" name="video_link" 
               value="<?= $edit_mode ? htmlspecialchars($current_workout['video_link']) : (isset($_POST['video_link']) ? htmlspecialchars($_POST['video_link']) : '') ?>" 
               placeholder="Paste workout video link">

        <label for="image_urls">Image URLs (comma separated)</label>
        <textarea id="image_urls" name="image_urls" placeholder="Paste image URLs separated by commas"><?= $edit_mode ? htmlspecialchars($current_workout['image_urls']) : (isset($_POST['image_urls']) ? htmlspecialchars($_POST['image_urls']) : '') ?></textarea>
        <div class="form-note">Add multiple image URLs separated by commas for the image slider</div>

        <div class="form-buttons">
          <button type="submit" class="btn-primary">
            <?= $edit_mode ? 'Update Workout' : 'Add Workout' ?>
          </button>
          <?php if ($edit_mode): ?>
            <a href="adminAddWorkout.php" class="btn-secondary" style="text-decoration: none; text-align: center; line-height: 40px;">
              Cancel
            </a>
          <?php endif; ?>
        </div>
      </form>
    </div>

    <!-- Workouts List -->
    <div class="workouts-container">
      <h2>Manage Existing Workouts</h2>
      <?php if (!empty($workouts)): ?>
        <table class="workouts-table">
          <thead>
            <tr>
              <th>Name</th>
              <th>Category</th>
              <th>Difficulty</th>
              <th>Duration</th>
              <th>Actions</th>
            </tr>
          </thead>
          <tbody>
            <?php foreach($workouts as $workout): ?>
              <tr>
                <td><?= htmlspecialchars($workout['workout_name']) ?></td>
                <td><?= htmlspecialchars($workout['category']) ?></td>
                <td>
                  <span class="difficulty-badge difficulty-<?= strtolower($workout['difficulty_level']) ?>">
                    <?= htmlspecialchars($workout['difficulty_level']) ?>
                  </span>
                </td>
                <td><?= (int)$workout['duration'] ?> mins</td>
                <td>
                  <div class="action-buttons">
                    <a href="adminAddWorkout.php?edit=<?= $workout['id'] ?>" class="btn-edit">Edit</a>
                    <a href="adminAddWorkout.php?delete=<?= $workout['id'] ?>" 
                       class="btn-delete" 
                       onclick="return confirm('Are you sure you want to delete <?= htmlspecialchars($workout['workout_name']) ?>?')">
                      Delete
                    </a>
                  </div>
                </td>
              </tr>
            <?php endforeach; ?>
          </tbody>
        </table>
      <?php else: ?>
        <div class="no-workouts">
          <p>No workouts found. Add your first workout using the form.</p>
        </div>
      <?php endif; ?>
    </div>
  </div>

   <footer>
    <div class="footer-content">
      <p>&copy;2025 Fitness Club All rights reserved.</p>
    </div>
    <div class="linkes">
      <a href="workoutPrograms.php">View Public Page</a>
      <a href="#">Privacy Policy</a>
      <a href="#">Terms of Service</a>
    </div>
  </footer>

</body>
</html>