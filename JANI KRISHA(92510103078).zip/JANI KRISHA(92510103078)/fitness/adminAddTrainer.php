<?php
// adminAddTrainer.php

// Database connection
$host = "localhost";
$user = "root";
$password = "";
$database = "fitness_club";

$conn = new mysqli($host, $user, $password, $database);
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

$success_message = "";
$error_message = "";
$edit_mode = false;
$current_trainer = null;

// Handle form submission for ADD and UPDATE
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if (isset($_POST['trainer_id']) && !empty($_POST['trainer_id'])) {
        // UPDATE operation
        $trainer_id = (int)$_POST['trainer_id'];
        $name = $conn->real_escape_string($_POST['name']);
        $specialization = $conn->real_escape_string($_POST['specialization']);
        $experience = (int)$_POST['experience'];
        $certification = $conn->real_escape_string($_POST['certification']);
        $photo_url = $conn->real_escape_string($_POST['photo_url']);
        
        $sql = "UPDATE trainers SET 
                name = '$name', 
                specialization = '$specialization', 
                experience = $experience, 
                certification = '$certification', 
                photo_url = '$photo_url' 
                WHERE id = $trainer_id";
        
        if ($conn->query($sql) === TRUE) {
            $success_message = "Trainer updated successfully!";
            $edit_mode = false;
        } else {
            $error_message = "Error updating trainer: " . $conn->error;
        }
    } else {
        // ADD operation
        $name = $conn->real_escape_string($_POST['name']);
        $specialization = $conn->real_escape_string($_POST['specialization']);
        $experience = (int)$_POST['experience'];
        $certification = $conn->real_escape_string($_POST['certification']);
        $photo_url = $conn->real_escape_string($_POST['photo_url']);
        
        $sql = "INSERT INTO trainers (name, specialization, experience, certification, photo_url) 
                VALUES ('$name', '$specialization', $experience, '$certification', '$photo_url')";
        
        if ($conn->query($sql) === TRUE) {
            $success_message = "Trainer added successfully!";
        } else {
            $error_message = "Error adding trainer: " . $conn->error;
        }
    }
}

// Handle EDIT request
if (isset($_GET['edit'])) {
    $trainer_id = (int)$_GET['edit'];
    $sql = "SELECT * FROM trainers WHERE id = $trainer_id";
    $result = $conn->query($sql);
    
    if ($result && $result->num_rows > 0) {
        $current_trainer = $result->fetch_assoc();
        $edit_mode = true;
    }
}

// Handle DELETE request
if (isset($_GET['delete'])) {
    $trainer_id = (int)$_GET['delete'];
    $sql = "DELETE FROM trainers WHERE id = $trainer_id";
    
    if ($conn->query($sql) === TRUE) {
        $success_message = "Trainer deleted successfully!";
    } else {
        $error_message = "Error deleting trainer: " . $conn->error;
    }
}

// Fetch all trainers for the table
$sql = "SELECT * FROM trainers ORDER BY name";
$trainers_result = $conn->query($sql);
$trainers = [];
if ($trainers_result && $trainers_result->num_rows > 0) {
    while ($row = $trainers_result->fetch_assoc()) {
        $trainers[] = $row;
    }
}

$conn->close();
?>

<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1" />
  <title>Manage Trainers - Admin Panel</title>
  <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@400;600&display=swap" rel="stylesheet" />
  <style>
    * {
      margin: 0;
      padding: 0;
      box-sizing: border-box;
      font-family: 'Poppins', sans-serif;
    }
    body {
      background: #f4f7fa;
      color: #333;
    }

    /* Header */
    header {
      background: #2c3e50;
      padding: 15px 30px;
      color: #fff;
    }
    .header-container {
      max-width: 1200px;
      margin: 0 auto;
      display: flex;
      align-items: center;
      justify-content: space-between;
    }
    header h1 {
      font-size: 22px;
      font-weight: 600;
    }
    .main-nav a {
      color: #fff;
      margin-left: 20px;
      text-decoration: none;
      font-weight: 500;
      transition: 0.3s ease;
    }
    .main-nav a:hover {
      color: #00bcd4;
    }

    /* Success/Error Messages */
    .message {
      padding: 15px;
      margin: 20px auto;
      max-width: 1200px;
      border-radius: 8px;
      text-align: center;
      font-weight: bold;
    }
    .success {
      background: #d4edda;
      color: #155724;
      border: 1px solid #c3e6cb;
    }
    .error {
      background: #f8d7da;
      color: #721c24;
      border: 1px solid #f5c6cb;
    }

    /* Main Container */
    .main-container {
      max-width: 1200px;
      margin: 20px auto;
      padding: 0 20px;
      display: grid;
      grid-template-columns: 1fr 1fr;
      gap: 30px;
    }

    /* Form Container */
    .form-container {
      background: #fff;
      padding: 30px;
      border-radius: 12px;
      box-shadow: 0 4px 15px rgba(0,0,0,0.1);
    }
    .form-container h2 {
      margin-bottom: 20px;
      text-align: center;
      color: #00bcd4;
    }

    label {
      display: block;
      margin-bottom: 8px;
      font-weight: 600;
    }
    input, textarea, select {
      width: 100%;
      padding: 10px;
      margin-bottom: 18px;
      border: 1px solid #ccc;
      border-radius: 8px;
      outline: none;
      transition: 0.3s ease;
    }
    input:focus, textarea:focus, select:focus {
      border-color: #00bcd4;
      box-shadow: 0 0 5px rgba(0,188,212,0.4);
    }

    .form-buttons {
      display: flex;
      gap: 10px;
    }
    button {
      flex: 1;
      padding: 12px;
      border: none;
      border-radius: 8px;
      cursor: pointer;
      transition: 0.3s ease;
      font-weight: 600;
    }
    .btn-primary {
      background: #00bcd4;
      color: #fff;
    }
    .btn-primary:hover {
      background: #0195a3;
    }
    .btn-secondary {
      background: #6c757d;
      color: #fff;
    }
    .btn-secondary:hover {
      background: #545b62;
    }
    .btn-cancel {
      background: #dc3545;
      color: #fff;
    }
    .btn-cancel:hover {
      background: #c82333;
    }

    /* Trainers Table */
    .trainers-container {
      background: #fff;
      padding: 30px;
      border-radius: 12px;
      box-shadow: 0 4px 15px rgba(0,0,0,0.1);
    }
    .trainers-container h2 {
      margin-bottom: 20px;
      text-align: center;
      color: #00bcd4;
    }

    .trainers-table {
      width: 100%;
      border-collapse: collapse;
      margin-top: 20px;
    }
    .trainers-table th,
    .trainers-table td {
      padding: 12px;
      text-align: left;
      border-bottom: 1px solid #ddd;
    }
    .trainers-table th {
      background: #f8f9fa;
      font-weight: 600;
      color: #2c3e50;
    }
    .trainers-table tr:hover {
      background: #f8f9fa;
    }
    .trainer-photo {
      width: 50px;
      height: 50px;
      border-radius: 50%;
      object-fit: cover;
      border: 2px solid #00bcd4;
    }
    .action-buttons {
      display: flex;
      gap: 5px;
    }
    .btn-edit {
      background: #28a745;
      color: white;
      padding: 6px 12px;
      border: none;
      border-radius: 4px;
      cursor: pointer;
      text-decoration: none;
      font-size: 12px;
    }
    .btn-edit:hover {
      background: #218838;
    }
    .btn-delete {
      background: #dc3545;
      color: white;
      padding: 6px 12px;
      border: none;
      border-radius: 4px;
      cursor: pointer;
      text-decoration: none;
      font-size: 12px;
    }
    .btn-delete:hover {
      background: #c82333;
    }

    .no-trainers {
      text-align: center;
      padding: 40px;
      color: #6c757d;
    }

    footer {
      background: #2c3e50;
      color: #fff;
      text-align: center;
      padding: 15px;
      margin-top: 40px;
    }
    .footer-content {
      margin-bottom: 10px;
    }
    .linkes a {
      color: #fff;
      margin: 0 10px;
      text-decoration: none;
    }
    .linkes a:hover {
      text-decoration: underline;
    }

    @media (max-width: 768px) {
      .main-container {
        grid-template-columns: 1fr;
      }
    }
  </style>
</head>
<body>
<header>
  <div class="header-container">
    <h1>Fitness Club - Admin Panel</h1>
    <nav class="main-nav">
      <a href="adminAddWorkout.html">Upload Workout</a>
      <a href="adminAddTrainer.php" class="active">Manage Trainers</a>
      <a href="home.html">Dashboard</a>
      <a href="aboutUs.html">Logout</a>
    </nav>
  </div>
</header>

<?php if ($success_message): ?>
  <div class="message success">
    <?= $success_message ?>
  </div>
<?php endif; ?>

<?php if ($error_message): ?>
  <div class="message error">
    <?= $error_message ?>
  </div>
<?php endif; ?>

<div class="main-container">
  <!-- Add/Edit Form -->
  <div class="form-container">
    <h2><?= $edit_mode ? 'Edit Trainer' : 'Add New Trainer' ?></h2>
    <form method="POST" action="">
      <?php if ($edit_mode): ?>
        <input type="hidden" name="trainer_id" value="<?= $current_trainer['id'] ?>">
      <?php endif; ?>
      
      <label for="name">Full Name</label>
      <input type="text" id="name" name="name" 
             value="<?= $edit_mode ? htmlspecialchars($current_trainer['name']) : '' ?>" 
             placeholder="Enter trainer's full name" required>

      <label for="specialization">Specialization</label>
      <input type="text" id="specialization" name="specialization" 
             value="<?= $edit_mode ? htmlspecialchars($current_trainer['specialization']) : '' ?>" 
             placeholder="e.g. Yoga, Strength Training" required>

      <label for="experience">Experience (Years)</label>
      <input type="number" id="experience" name="experience" 
             value="<?= $edit_mode ? $current_trainer['experience'] : '' ?>" 
             placeholder="Enter years of experience" required min="0">

      <label for="certification">Certification</label>
      <input type="text" id="certification" name="certification" 
             value="<?= $edit_mode ? htmlspecialchars($current_trainer['certification']) : '' ?>" 
             placeholder="Enter certification details" required>

      <label for="photo">Photo (URL)</label>
      <input type="url" id="photo" name="photo_url" 
             value="<?= $edit_mode ? htmlspecialchars($current_trainer['photo_url']) : '' ?>" 
             placeholder="Paste image URL" required>

      <div class="form-buttons">
        <button type="submit" class="btn-primary">
          <?= $edit_mode ? 'Update Trainer' : 'Add Trainer' ?>
        </button>
        <?php if ($edit_mode): ?>
          <a href="adminAddTrainer.php" class="btn-secondary" style="text-decoration: none; text-align: center; line-height: 40px;">
            Cancel
          </a>
        <?php endif; ?>
      </div>
    </form>
  </div>

  <!-- Trainers List -->
  <div class="trainers-container">
    <h2>Manage Existing Trainers</h2>
    <?php if (!empty($trainers)): ?>
      <table class="trainers-table">
        <thead>
          <tr>
            <th>Photo</th>
            <th>Name</th>
            <th>Specialization</th>
            <th>Experience</th>
            <th>Actions</th>
          </tr>
        </thead>
        <tbody>
          <?php foreach($trainers as $trainer): ?>
            <tr>
              <td>
                <img src="<?= htmlspecialchars($trainer['photo_url']) ?>" 
                     alt="<?= htmlspecialchars($trainer['name']) ?>" 
                     class="trainer-photo"
                     onerror="this.src='https://via.placeholder.com/50/00bcd4/ffffff?text=T'">
              </td>
              <td><?= htmlspecialchars($trainer['name']) ?></td>
              <td><?= htmlspecialchars($trainer['specialization']) ?></td>
              <td><?= (int)$trainer['experience'] ?> years</td>
              <td>
                <div class="action-buttons">
                  <a href="adminAddTrainer.php?edit=<?= $trainer['id'] ?>" class="btn-edit">Edit</a>
                  <a href="adminAddTrainer.php?delete=<?= $trainer['id'] ?>" 
                     class="btn-delete" 
                     onclick="return confirm('Are you sure you want to delete <?= htmlspecialchars($trainer['name']) ?>?')">
                    Delete
                  </a>
                </div>
              </td>
            </tr>
          <?php endforeach; ?>
        </tbody>
      </table>
    <?php else: ?>
      <div class="no-trainers">
        <p>No trainers found. Add your first trainer using the form.</p>
      </div>
    <?php endif; ?>
  </div>
</div>

<footer>
  <div class="footer-content">
    <p>&copy;2025 Fitness Club All rights reserved.</p>
  </div>
  <div class="linkes">
    <a href="trainerInfo.php">View Public Page</a>
    <a href="#">Privacy Policy</a>
    <a href="#">Terms of Service</a>
  </div>
</footer>
</body>
</html>