<?php if ($added_success): ?>
  <p style="color: green; font-weight: bold; text-align:center;">
    Trainer added successfully!
  </p>
<?php endif; ?>
