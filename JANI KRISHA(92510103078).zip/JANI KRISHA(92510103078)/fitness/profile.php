<?php
session_start();

// Check if user is logged in
if (!isset($_SESSION['logged_in']) || $_SESSION['logged_in'] !== true) {
    header("Location: login.html");
    exit();
}

// Database connection
$conn = new mysqli("localhost", "root", "", "fitness_club");
if ($conn->connect_error) {
    die("Database connection failed: " . $conn->connect_error);
}

// Fetch user data
$email = $_SESSION['email'];
$sql = "SELECT * FROM users WHERE email = ?";
$stmt = $conn->prepare($sql);
$stmt->bind_param("s", $email);
$stmt->execute();
$result = $stmt->get_result();
$user = $result->fetch_assoc();
$stmt->close();

// --- Update user profile when form is submitted ---
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['save'])) {
    $new_username = $_POST['username'];
    $new_contact = $_POST['contact'];

    $update_sql = "UPDATE users SET username = ?, contact = ? WHERE email = ?";
    $update_stmt = $conn->prepare($update_sql);
    $update_stmt->bind_param("sss", $new_username, $new_contact, $email);

    if ($update_stmt->execute()) {
        echo "<script>alert('✅ Profile updated successfully!');</script>";
        $user['username'] = $new_username;
        $user['contact'] = $new_contact;
    } else {
        echo "<script>alert('❌ Error updating profile.');</script>";
    }

    $update_stmt->close();
}

$conn->close();
?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Profile - Fitness Club</title>
<link href="https://fonts.googleapis.com/css2?family=Poppins:wght@400;600&display=swap" rel="stylesheet">
<style>
  * {
    margin: 0;
    padding: 0;
    box-sizing: border-box;
  }

  body {
    font-family: 'Poppins', sans-serif;
    background-color: #f0f2f5;
    color: #333;
    line-height: 1.6;
  }

  /* Header */
  header {
    background: linear-gradient(90deg, #0f2027, #203a43, #2c5364);
    color: white;
    padding: 20px 0;
  }

  .header-container {
    max-width: 1200px;
    margin: 0 auto;
    padding: 0 20px;
    display: flex;
    justify-content: space-between;
    align-items: center;
    flex-wrap: wrap;
  }

  header h1 {
    font-size: 2rem;
  }

  nav {
    display: flex;
    gap: 15px;
    flex-wrap: wrap;
  }

  nav a {
    background-color: #00bcd4;
    color: white;
    padding: 8px 14px;
    border-radius: 5px;
    font-weight: 600;
    text-decoration: none;
    transition: background-color 0.3s ease;
  }

  nav a:hover {
    background-color: #0195a3;
  }

  /* Main Content */
  main {
    max-width: 700px;
    margin: 40px auto;
    background-color: #fff;
    border-radius: 10px;
    box-shadow: 0 5px 15px rgba(0,0,0,0.05);
    padding: 40px;
  }

  main h2 {
    font-size: 1.8rem;
    text-align: center;
    margin-bottom: 25px;
    color: #2c3e50;
  }

  label {
    font-weight: 600;
    margin-top: 10px;
    display: block;
  }

  input[type="text"],
  input[type="email"],
  input[type="tel"] {
    width: 100%;
    padding: 10px;
    margin-top: 5px;
    border-radius: 5px;
    border: 1px solid #ccc;
    font-size: 1rem;
  }

  .btn {
    display: inline-block;
    margin-top: 20px;
    padding: 10px 20px;
    background-color: #00bcd4;
    color: white;
    border-radius: 5px;
    border: none;
    cursor: pointer;
    font-weight: 600;
    text-decoration: none;
  }

  .btn:hover {
    background-color: #0195a3;
  }

  footer {
    background-color: #2c3e50;
    color: #ecf0f1;
    text-align: center;
    padding: 20px;
    margin-top: 60px;
  }

  .linkes {
    margin-top: 10px;
  }

  .linkes a {
    color: #00bcd4;
    margin: 0 10px;
    text-decoration: none;
    font-size: 0.9rem;
  }

  .linkes a:hover {
    text-decoration: underline;
  }

  @media (max-width: 768px) {
    .header-container {
      flex-direction: column;
      align-items: center;
      gap: 10px;
    }

    nav {
      justify-content: center;
    }

    main {
      padding: 20px;
    }
  }
</style>

<script>
function enableEdit() {
  document.getElementById('username').disabled = false;
  document.getElementById('contact').disabled = false;
  document.getElementById('saveBtn').style.display = 'inline-block';
}
</script>
</head>
<body>

<header>
  <div class="header-container">
    <h1>Fitness Club</h1>
    <nav>
      <a href="home.html">Home</a>
      <a href="dietPlans.html">Diet Plans</a>
      <a href="trainersInfo.html">Visit Trainer</a>
      <a href="aboutUs.html">About Us</a>
    </nav>
  </div>
</header>

<main>
  <h2>My Profile</h2>

  <form method="POST" action="">
    <label>Username:</label>
    <input type="text" id="username" name="username" value="<?php echo htmlspecialchars($user['username']); ?>" disabled>

    <label>Email:</label>
    <input type="email" value="<?php echo htmlspecialchars($user['email']); ?>" disabled>

    <label>Contact No:</label>
    <input type="tel" id="contact" name="contact" value="<?php echo htmlspecialchars($user['contact']); ?>" disabled>

    <button type="button" class="btn" onclick="enableEdit()">Update Profile</button>
    <button type="submit" name="save" id="saveBtn" class="btn" style="display:none;">Save Profile</button>
    <a href="logout.php" class="btn">Logout</a>
  </form>
</main>

<footer>
  <div class="footer-content">
    <p>&copy;2025 Fitness Club All rights reserved.</p>
  </div>
  <div class="linkes">
    <a href="#">Privacy Policy</a>
    <a href="#">Terms of Service</a>
    <a href="#">Contact Us</a>
  </div>
</footer>

</body>
</html>
