<?php
// workoutPrograms.php

// Database connection
$host = "localhost";
$user = "root";
$password = "";
$database = "fitness_club";

$conn = new mysqli($host, $user, $password, $database);
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Fetch all workouts grouped by category
$sql = "SELECT * FROM workouts ORDER BY category, workout_name";
$result = $conn->query($sql);

$workouts_by_category = [];
if ($result && $result->num_rows > 0) {
    while ($row = $result->fetch_assoc()) {
        $category = $row['category'];
        if (!isset($workouts_by_category[$category])) {
            $workouts_by_category[$category] = [];
        }
        $workouts_by_category[$category][] = $row;
    }
}

$conn->close();
?>

<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1.0"/>
  <title>Workout Programs - Fitness Club</title>
  <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@400;600&display=swap" rel="stylesheet" />
  <style>
    * {
      margin: 0;
      padding: 0;
      box-sizing: border-box;
    }

    body {
      font-family: 'Poppins', sans-serif;
      background-color: #f0f2f5;
      color: #333;
    }

    /* Header */
    header {
      background: linear-gradient(90deg, #0f2027, #203a43, #2c5364);
      color: white;
      padding: 20px 0;
    }

    .header-container {
      max-width: 1200px;
      margin: 0 auto;
      padding: 0 20px;
      display: flex;
      justify-content: space-between;
      align-items: center;
      flex-wrap: wrap;
    }

    header h1 {
      font-size: 2rem;
    }

    nav {
      display: flex;
      gap: 15px;
      flex-wrap: wrap;
    }

    nav a {
      background-color: #00bcd4;
      color: white;
      padding: 8px 14px;
      border-radius: 5px;
      font-weight: 600;
      text-decoration: none;
      transition: background-color 0.3s ease;
    }

    nav a:hover {
      background-color: #0195a3;
    }

    /* Main Content */
    main {
      max-width: 1200px;
      margin: 40px auto;
      padding: 0 20px;
    }

    h2 {
      text-align: center;
      font-size: 2rem;
      margin-bottom: 40px;
      color: #2c3e50;
    }

    .category-section {
      background-color: #fff;
      border-radius: 10px;
      box-shadow: 0 5px 15px rgba(0,0,0,0.05);
      padding: 30px;
      margin-bottom: 40px;
    }

    .category-section h3 {
      font-size: 1.8rem;
      color: #00bcd4;
      margin-bottom: 25px;
      text-align: center;
      border-bottom: 2px solid #00bcd4;
      padding-bottom: 10px;
    }

    .workouts-grid {
      display: grid;
      grid-template-columns: repeat(auto-fit, minmax(350px, 1fr));
      gap: 25px;
    }

    .workout-card {
      background: #f8f9fa;
      border-radius: 10px;
      padding: 20px;
      box-shadow: 0 3px 10px rgba(0,0,0,0.1);
      transition: transform 0.3s ease;
    }

    .workout-card:hover {
      transform: translateY(-5px);
    }

    .workout-card h4 {
      font-size: 1.3rem;
      color: #2c3e50;
      margin-bottom: 10px;
    }

    .workout-meta {
      display: flex;
      gap: 15px;
      margin-bottom: 15px;
      font-size: 0.9rem;
      color: #666;
    }

    .difficulty-badge {
      padding: 3px 8px;
      border-radius: 12px;
      font-size: 0.8rem;
      font-weight: 600;
    }

    .difficulty-beginner {
      background: #d4edda;
      color: #155724;
    }

    .difficulty-intermediate {
      background: #fff3cd;
      color: #856404;
    }

    .difficulty-advanced {
      background: #f8d7da;
      color: #721c24;
    }

    .workout-card p {
      color: #555;
      margin-bottom: 15px;
      line-height: 1.5;
    }

    /* Slider styles */
    .slider {
      position: relative;
      width: 100%;
      margin: 15px 0;
      overflow: hidden;
      border-radius: 8px;
    }

    .slides {
      display: flex;
      transition: transform 0.5s ease;
    }

    .slides img {
      width: 100%;
      flex-shrink: 0;
      border-radius: 8px;
      height: 200px;
      object-fit: cover;
    }

    input[type=radio] {
      display: none;
    }

    /* Navigation dots */
    .nav {
      text-align: center;
      margin-top: 10px;
    }

    .nav label {
      display: inline-block;
      width: 12px;
      height: 12px;
      border-radius: 50%;
      background: #bbb;
      margin: 0 5px;
      cursor: pointer;
    }

    .video-link {
      display: inline-block;
      background: #00bcd4;
      color: white;
      padding: 8px 15px;
      border-radius: 5px;
      text-decoration: none;
      font-weight: 600;
      margin-top: 10px;
      transition: background 0.3s ease;
    }

    .video-link:hover {
      background: #0195a3;
    }

    .no-workouts {
      text-align: center;
      padding: 40px;
      color: #666;
      font-style: italic;
    }

    .admin-link {
      text-align: center;
      margin: 30px 0;
    }

    .admin-link a {
      background: #2c3e50;
      color: white;
      padding: 12px 25px;
      text-decoration: none;
      border-radius: 5px;
      font-weight: bold;
      transition: background 0.3s ease;
    }

    .admin-link a:hover {
      background: #34495e;
    }

    /* Footer */
    footer {
      background-color: #2c3e50;
      color: #ecf0f1;
      text-align: center;
      padding: 20px;
      margin-top: 60px;
    }

    .linkes {
      margin-top: 10px;
    }

    .linkes a {
      color: #00bcd4;
      margin: 0 10px;
      text-decoration: none;
      font-size: 0.9rem;
    }

    .linkes a:hover {
      text-decoration: underline;
    }

    @media (max-width: 768px) {
      .workouts-grid {
        grid-template-columns: 1fr;
      }
      
      .header-container {
        flex-direction: column;
        gap: 15px;
      }
    }
  </style>
</head>
<body>

   <header>
    <div class="header-container">
        <h1>Fitness Club</h1>
        <nav class="main-nav">
            <a href="home.html">Home</a>
            <a href="trainerInfo.php">Our Trainers</a>
            <a href="workoutPrograms.php" class="active">Workout Programs</a>
            <a href="aboutUs.html">About Us</a>
        </nav>
    </div>
  </header>

  <main>
    <h2>Workout Programs</h2>

    <!-- <div class="admin-link">
      <a href="adminAddWorkout.php">Add New Workout (Admin)</a>
    </div> -->

    <?php if (!empty($workouts_by_category)): ?>
      <?php foreach($workouts_by_category as $category => $workouts): ?>
        <section class="category-section">
          <h3><?= htmlspecialchars($category) ?></h3>
          <div class="workouts-grid">
            <?php foreach($workouts as $workout): 
              $image_urls = !empty($workout['image_urls']) ? explode(',', $workout['image_urls']) : [];
              $slider_id = 'slider-' . $workout['id'];
            ?>
              <div class="workout-card">
                <h4><?= htmlspecialchars($workout['workout_name']) ?></h4>
                
                <div class="workout-meta">
                  <span>Duration: <?= (int)$workout['duration'] ?> mins</span>
                  <span class="difficulty-badge difficulty-<?= strtolower($workout['difficulty_level']) ?>">
                    <?= htmlspecialchars($workout['difficulty_level']) ?>
                  </span>
                </div>

                <?php if (!empty($image_urls)): ?>
                  <div class="slider">
                    <?php foreach($image_urls as $index => $url): ?>
                      <input type="radio" name="<?= $slider_id ?>" id="<?= $slider_id . '-' . ($index + 1) ?>" <?= $index === 0 ? 'checked' : '' ?>>
                    <?php endforeach; ?>

                    <div class="slides">
                      <?php foreach($image_urls as $url): ?>
                        <img src="<?= htmlspecialchars(trim($url)) ?>" 
                             alt="<?= htmlspecialchars($workout['workout_name']) ?>" 
                             onerror="this.src='https://via.placeholder.com/400x200/00bcd4/ffffff?text=Workout+Image'">
                      <?php endforeach; ?>
                    </div>

                    <div class="nav">
                      <?php foreach($image_urls as $index => $url): ?>
                        <label for="<?= $slider_id . '-' . ($index + 1) ?>"></label>
                      <?php endforeach; ?>
                    </div>
                  </div>
                <?php else: ?>
                  <img src="https://via.placeholder.com/400x200/00bcd4/ffffff?text=No+Image" 
                       alt="No image" style="width: 100%; height: 200px; object-fit: cover; border-radius: 8px;">
                <?php endif; ?>

                <?php if (!empty($workout['description'])): ?>
                  <p><?= htmlspecialchars($workout['description']) ?></p>
                <?php endif; ?>

                <?php if (!empty($workout['video_link'])): ?>
                  <a href="<?= htmlspecialchars($workout['video_link']) ?>" target="_blank" class="video-link">
                    Watch Video
                  </a>
                <?php endif; ?>
              </div>
            <?php endforeach; ?>
          </div>
        </section>
      <?php endforeach; ?>
    <?php else: ?>
      <div class="no-workouts">
        <h3>No workouts available yet</h3>
        <p>Check back later for amazing workout programs!</p>
        <div style="margin-top: 20px;">
          <!-- <a href="adminAddWorkout.php" style="background: #00bcd4; color: white; padding: 10px 20px; text-decoration: none; border-radius: 5px;">
            Add First Workout
          </a> -->
        </div>
      </div>
    <?php endif; ?>
  </main>

  <footer>
    <div class="footer-content">
      <p>&copy;2025 Fitness Club All rights reserved.</p>
    </div>
    <div class="linkes">
      <a href="#">Privacy Policy</a>
      <a href="#">Terms and Service</a>
      <a href="#">Contact Us</a>
    </div>
  </footer>

</body>
</html>