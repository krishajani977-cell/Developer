<?php
session_start();

// Database connection
$conn = new mysqli("localhost", "root", "", "fitness_club");
if ($conn->connect_error) {
    die("Connection Failed: " . $conn->connect_error);
}

$email = $_POST['email'];
$password = $_POST['password'];
$remember = isset($_POST['remember']);

// --- Admin credentials ---
$admin_email = "admin@fitnessclub.com";
$admin_pass = "admin123";

if ($email === $admin_email && $password === $admin_pass) {
    $_SESSION['username'] = "Admin";
    $_SESSION['role'] = "admin";
    $_SESSION['logged_in'] = true;

    echo "<script>alert('✅ Admin Login Successful!'); window.location.href='admin_home.php';</script>";
    exit;
}

// --- Normal user login ---
$sql = "SELECT * FROM users WHERE email = ?";
$stmt = $conn->prepare($sql);
$stmt->bind_param("s", $email);
$stmt->execute();
$result = $stmt->get_result();

if ($result->num_rows > 0) {
    $user = $result->fetch_assoc();

    if (password_verify($password, $user['password'])) {
        $_SESSION['username'] = $user['username'];
        $_SESSION['email'] = $user['email'];
        $_SESSION['role'] = "user";
        $_SESSION['logged_in'] = true;

        echo "<script>alert('✅ Login Successful! Welcome, {$user['username']}'); window.location.href='home.html';</script>";
    } else {
        echo "<script>alert('❌ Incorrect Password!'); window.history.back();</script>";
    }
} else {
    echo "<script>alert('❌ Email not registered!'); window.history.back();</script>";
}

$stmt->close();
$conn->close();
?>
