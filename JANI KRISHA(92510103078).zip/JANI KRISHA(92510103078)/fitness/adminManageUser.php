<?php
session_start();

// Security check: allow only admin
if (!isset($_SESSION['role']) || $_SESSION['role'] !== 'admin') {
    header("Location: login.html");
    exit();
}

// Database connection
$host = "localhost";
$user = "root";
$pass = "";
$dbname = "fitness_club"; // ✅ Correct database name

$conn = new mysqli($host, $user, $pass, $dbname);
if ($conn->connect_error) {
    die("Database connection failed: " . $conn->connect_error);
}

// Handle delete action
if (isset($_GET['delete'])) {
    $id = intval($_GET['delete']);
    $conn->query("DELETE FROM registrations WHERE id = $id");
    header("Location: adminManageUser.php");
    exit();
}

// Fetch all users from registrations table
$result = $conn->query("SELECT id, username, email, contact, created_at FROM registrations ORDER BY id ASC");
?>

<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Manage Users - Fitness Club Admin</title>
  <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@400;600&display=swap" rel="stylesheet">
  <style>
    * { margin: 0; padding: 0; box-sizing: border-box; }
    body {
      font-family: 'Poppins', sans-serif;
      background-color: #f0f2f5;
      color: #333;
      line-height: 1.6;
    }

    header {
      background: linear-gradient(90deg, #0f2027, #203a43, #2c5364);
      color: white;
      padding: 20px 0;
      text-align: center;
    }
    header h1 { font-size: 1.8rem; }

    section {
      max-width: 900px;
      margin: 40px auto;
      background: #fff;
      padding: 30px;
      border-radius: 10px;
      box-shadow: 0 5px 15px rgba(0,0,0,0.1);
    }

    h2 {
      text-align: center;
      color: #2c3e50;
      margin-bottom: 20px;
    }

    table {
      width: 100%;
      border-collapse: collapse;
      margin-top: 10px;
    }

    th, td {
      padding: 12px 15px;
      border-bottom: 1px solid #ddd;
      text-align: center;
    }

    th {
      background-color: #00bcd4;
      color: white;
      font-weight: 600;
    }

    tr:hover {
      background-color: #f9f9f9;
    }

    .btn {
      display: inline-block;
      padding: 8px 15px;
      border-radius: 5px;
      color: white;
      text-decoration: none;
      font-size: 0.9rem;
      transition: background 0.3s ease;
    }

    .delete-btn {
      background-color: #e74c3c;
    }

    .delete-btn:hover {
      background-color: #c0392b;
    }

    .back-btn {
      display: inline-block;
      background-color: #2ecc71;
      color: white;
      padding: 10px 20px;
      border-radius: 5px;
      font-weight: 600;
      text-decoration: none;
      margin-top: 20px;
      transition: background 0.3s;
    }

    .back-btn:hover {
      background-color: #27ae60;
    }

    footer {
      background-color: #2c3e50;
      color: #ecf0f1;
      text-align: center;
      padding: 20px;
      margin-top: 40px;
    }
  </style>
</head>
<body>

<header>
  <h1>Manage Users - Admin Panel</h1>
</header>

<section>
  <h2>Registered Users</h2>

  <table>
    <tr>
      <th>ID</th>
      <th>Username</th>
      <th>Email</th>
      <th>Contact</th>
      <th>Created At</th>
      <th>Action</th>
    </tr>
    <?php while ($row = $result->fetch_assoc()) { ?>
      <tr>
        <td><?php echo $row['id']; ?></td>
        <td><?php echo htmlspecialchars($row['username']); ?></td>
        <td><?php echo htmlspecialchars($row['email']); ?></td>
        <td><?php echo htmlspecialchars($row['contact']); ?></td>
        <td><?php echo htmlspecialchars($row['created_at']); ?></td>
        <td>
          <a href="adminManageUser.php?delete=<?php echo $row['id']; ?>" 
             class="btn delete-btn" 
             onclick="return confirm('Are you sure you want to delete this user?');">
             Delete
          </a>
        </td>
      </tr>
    <?php } ?>
  </table>

  <div style="text-align:center;">
    <a href="admin_home.php" class="back-btn">⬅ Back to Dashboard</a>
  </div>
</section>

<footer>
  <p>&copy; 2025 Fitness Club. All rights reserved.</p>
</footer>

</body>
</html>

<?php $conn->close(); ?>
