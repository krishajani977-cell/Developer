<?php
session_start();

// Security check: allow only admin
if (!isset($_SESSION['role']) || $_SESSION['role'] !== 'admin') {
    header("Location: login.html");
    exit();
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Admin Dashboard - Fitness Club</title>
  <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@400;600&display=swap" rel="stylesheet">
  <style>
    * { margin: 0; padding: 0; box-sizing: border-box; }
    body {
      font-family: 'Poppins', sans-serif;
      background-color: #f0f2f5;
      color: #333;
      line-height: 1.6;
    }

    header {
      background: linear-gradient(90deg, #0f2027, #203a43, #2c5364);
      color: white;
      padding: 20px 0;
      text-align: center;
    }
    header h1 { font-size: 1.8rem; }

    section {
      max-width: 700px;
      margin: 50px auto;
      background: #fff;
      padding: 40px;
      border-radius: 10px;
      box-shadow: 0 5px 15px rgba(0,0,0,0.1);
      text-align: center;
    }

    section h2 {
      font-size: 1.8rem;
      margin-bottom: 25px;
      color: #2c3e50;
    }

    .btn-container {
      display: flex;
      flex-direction: column;
      gap: 15px;
      align-items: center;
      justify-content: center;
    }

    .btn {
      display: inline-block;
      background-color: #00bcd4;
      color: white;
      padding: 12px 25px;
      border-radius: 5px;
      font-size: 1rem;
      font-weight: 600;
      text-decoration: none;
      transition: background 0.3s ease;
      width: 250px;
      text-align: center;
    }

    .btn:hover {
      background-color: #0195a3;
    }

    .logout-btn {
      margin-top: 30px;
      background-color: #e74c3c;
    }

    .logout-btn:hover {
      background-color: #c0392b;
    }

    footer {
      background-color: #2c3e50;
      color: #ecf0f1;
      text-align: center;
      padding: 20px;
      margin-top: 60px;
    }

    .links a {
      color: #00bcd4;
      margin: 0 10px;
      text-decoration: none;
      font-size: 0.9rem;
    }

    .links a:hover {
      text-decoration: underline;
    }
  </style>
</head>
<body>

<header>
  <h1>Fitness Club Admin Panel</h1>
</header>

<section>
  <h2>Welcome, <?php echo $_SESSION['username']; ?> 👋</h2>
  <p>Manage your gym details and staff from here.</p>

  <div class="btn-container">
    <a href="adminAddWorkout.php" class="btn">➕ Add Workout</a>
    <a href="adminTrainer.html" class="btn">👨‍🏫 Add Trainer Info</a>
    <a href="adminManageUser.php" class="btn">👥 Manage Users</a> <!-- ✅ New Button -->
    <a href="logout.php" class="btn logout-btn">🚪 Logout</a>
  </div>
</section>

<footer>
  <p>&copy; 2025 Fitness Club. All rights reserved.</p>
  <div class="links">
    <a href="#">Privacy Policy</a>
    <a href="#">Terms of Service</a>
    <a href="#">Contact Us</a>
  </div>
</footer>

</body>
</html>
