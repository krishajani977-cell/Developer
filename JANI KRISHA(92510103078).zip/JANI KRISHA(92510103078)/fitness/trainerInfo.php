<?php
// trainerInfo.php

// Database connection
$host = "localhost";
$user = "root";
$password = "";
$database = "fitness_club";

$conn = new mysqli($host, $user, $password, $database);
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Fetch all trainers from database
$sql = "SELECT name, specialization, experience, certification, photo_url FROM trainers ORDER BY name";
$result = $conn->query($sql);

$trainers = [];
if ($result && $result->num_rows > 0) {
    while ($row = $result->fetch_assoc()) {
        $trainers[] = $row;
    }
}

$conn->close();

// Check if redirected from admin with success message
$added_success = isset($_GET['added']) && $_GET['added'] == 'true';
?>

<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1.0"/>
  <title>Our Trainers - Fitness Club</title>
  <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@400;600&display=swap" rel="stylesheet" />
  <style>
    header {
      background: linear-gradient(90deg, #0f2027, #203a43, #2c5364);
      color: white;
      padding: 20px;
    }

    .header-container {
      display: flex;
      justify-content: space-between;
      align-items: center;
      max-width: 1200px;
      margin: 0 auto;
    }

    header h1 {
      font-size: 2rem;
      margin: 0;
    }

    nav {
      display: flex;
      gap: 15px;
    }

    * {
      margin: 0;
      padding: 0;
      box-sizing: border-box;
      font-family: 'Poppins', sans-serif;
    }

    body {
      background: #f9f9f9;
      color: #333;
      line-height: 1.6;
    }

    header {
      background: linear-gradient(90deg, #0f2027, #203a43, #2c5364);
      color: #fff;
      padding: 20px;
      text-align: center;
    }
    
    header h1 {
      font-size: 28px;
      margin-bottom: 5px;
    }
    
    nav {
      margin-top: 10px;
    }
    
    nav a {
      text-decoration: none;
      color: #fff;
      background: #00bcd4;
      padding: 8px 14px;
      border-radius: 5px;
      margin: 0 5px;
      font-weight: 600;
      transition: background 0.3s ease;
    }
    
    nav a:hover,
    nav a.active {
      background: #0195a3;
    }

    .success-message {
      color: green;
      font-weight: bold;
      text-align: center;
      padding: 15px;
      background: #d4edda;
      margin: 20px auto;
      max-width: 1100px;
      border-radius: 5px;
      border: 1px solid #c3e6cb;
    }

    main {
      max-width: 1100px;
      margin: 30px auto;
      padding: 0 20px;
    }

    .trainer {
      background: #fff;
      padding: 20px;
      margin-bottom: 20px;
      border-radius: 10px;
      box-shadow: 0 2px 6px rgba(0,0,0,0.1);
      display: flex;
      align-items: center;
      gap: 20px;
      transition: transform 0.3s ease;
    }
    
    .trainer:hover {
      transform: translateY(-5px);
    }
    
    .trainer img {
      width: 150px;
      height: 150px;
      border-radius: 50%;
      object-fit: cover;
      border: 3px solid #00bcd4;
    }
    
    .trainer h2 {
      color: #00bcd4;
      margin-bottom: 10px;
    }
    
    .trainer p {
      margin-bottom: 6px;
    }

    .admin-link {
      text-align: center;
      margin: 20px 0;
    }
    
    .admin-link a {
      background: #2c3e50;
      color: white;
      padding: 10px 20px;
      text-decoration: none;
      border-radius: 5px;
      font-weight: bold;
    }
    
    .admin-link a:hover {
      background: #34495e;
    }

    footer {
      background: #2c3e50;
      color: #fff;
      text-align: center;
      padding: 15px;
      margin-top: 40px;
    }
  </style>
</head>
<body>

<header>
  <div class="header-container">
    <h1>Fitness Club</h1>
    <nav class="main-nav">
      <a href="home.html">Home</a>
      <a href="trainerInfo.php" class="active">Visit Trainer</a>
      <a href="aboutUs.html">About Us</a>
    </nav>
  </div>
</header>

<?php if ($added_success): ?>
  <div class="success-message">
    Trainer added successfully!
  </div>
<?php endif; ?>

<main>
  <h1>Meet Our Expert Trainers</h1>
  <p>Our certified trainers are here to guide you every step of your fitness journey.</p>
  
  <!-- <div class="admin-link">
    <a href="adminAddTrainer.php">Add New Trainer (Admin)</a>
  </div> -->

  <?php if (!empty($trainers)): ?>
    <?php foreach($trainers as $trainer): ?>
      <div class="trainer">
        <img src="<?= htmlspecialchars($trainer['photo_url']) ?>" alt="<?= htmlspecialchars($trainer['name']) ?>" 
             onerror="this.src='https://via.placeholder.com/150/00bcd4/ffffff?text=Trainer'">
        <div>
          <h2><?= htmlspecialchars($trainer['name']) ?></h2>
          <p><strong>Specialization:</strong> <?= htmlspecialchars($trainer['specialization']) ?></p>
          <p><strong>Experience:</strong> <?= (int)$trainer['experience'] ?> years</p>
          <p><strong>Certification:</strong> <?= htmlspecialchars($trainer['certification']) ?></p>
        </div>
      </div>
    <?php endforeach; ?>
  <?php else: ?>
    <div style="text-align: center; padding: 40px;">
      <h3>No trainers available</h3>
      <p>No trainers have been added yet. Please check back later or contact admin.</p>
      <div style="margin-top: 20px;">
        <a href="adminAddTrainer.php" style="background: #00bcd4; color: white; padding: 10px 20px; text-decoration: none; border-radius: 5px;">
          Add First Trainer
        </a>
      </div>
    </div>
  <?php endif; ?>
</main>

<footer>
  <p>&copy; 2025 Fitness Club. All rights reserved.</p>
</footer>

</body>
</html>