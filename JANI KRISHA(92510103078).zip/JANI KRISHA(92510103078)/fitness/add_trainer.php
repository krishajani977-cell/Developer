<?php
// add_trainer.php

// DB connection
$host = "localhost";
$user = "root";
$password = "";
$database = "fitness_club";

$conn = new mysqli($host, $user, $password, $database);
if ($conn->connect_error) {
  die("Connection failed: " . $conn->connect_error);
}

// Check POST data
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $name = $conn->real_escape_string($_POST['name']);
    $specialization = $conn->real_escape_string($_POST['specialization']);
    $experience = (int)$_POST['experience'];
    $certification = $conn->real_escape_string($_POST['certification']);
    $photo_url = $conn->real_escape_string($_POST['photo_url']);

    // Basic validation could be added here if needed

    $sql = "INSERT INTO trainers (name, specialization, experience, certification, photo_url)
            VALUES ('$name', '$specialization', $experience, '$certification', '$photo_url')";

    if ($conn->query($sql) === TRUE) {
        // Redirect to the trainer listing page after success
        header("Location: trainerInfo.php?added=1");
        exit;
    } else {
        echo "Error: " . $conn->error;
    }
} else {
    // Invalid request method
    header("Location: adminAddTrainer.php");
    exit;
}

$conn->close();
?>
