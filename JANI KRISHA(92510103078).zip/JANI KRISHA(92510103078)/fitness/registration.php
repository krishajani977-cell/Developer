<?php
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "fitness_club";

// Connect to database
$conn = new mysqli($servername, $username, $password, $dbname);
if ($conn->connect_error) {
    die("Database connection failed: " . $conn->connect_error);
}

$message = ""; // To store feedback messages

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $user = trim($_POST["username"]);
    $email = trim($_POST["email"]);
    $contact = trim($_POST["contact"]);
    $pass = $_POST["password"];
    $confirm = $_POST["confirm"];

    // Server-side validation
    if (empty($user) || empty($email) || empty($contact) || empty($pass) || empty($confirm)) {
        $message = "<p class='error'>⚠️ All fields are required!</p>";
    } elseif ($pass !== $confirm) {
        $message = "<p class='error'>❌ Passwords do not match!</p>";
    } else {
        // Check if email already exists
        $check = $conn->prepare("SELECT email FROM users WHERE email = ?");
        $check->bind_param("s", $email);
        $check->execute();
        $check->store_result();

        if ($check->num_rows > 0) {
            $message = "<p class='error'>⚠️ Email already registered!</p>";
        } else {
            // Hash password
            $hashed_password = password_hash($pass, PASSWORD_DEFAULT);

            // Insert data
            $sql = "INSERT INTO users (username, email, contact, password) VALUES (?, ?, ?, ?)";
            $stmt = $conn->prepare($sql);
            $stmt->bind_param("ssss", $user, $email, $contact, $hashed_password);

            if ($stmt->execute()) {
                // Save to CSV
                $file = fopen("users.csv", "a");
                if (!file_exists("users.csv") || filesize("users.csv") === 0) {
                    fputcsv($file, ["Username", "Email", "Contact"]);
                }
                fputcsv($file, [$user, $email, $contact]);
                fclose($file);

                $message = "<p class='success'>✅ Registration Successful!</p>";
            } else {
                $message = "<p class='error'>❌ Database error, please try again!</p>";
            }
            $stmt->close();
        }
        $check->close();
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Registered Users - Fitness Club</title>
<style>
body { font-family: 'Poppins', sans-serif; background: #f0f2f5; margin: 0; padding: 0; }
header { background: linear-gradient(90deg,#0f2027,#203a43,#2c5364); color: white; text-align:center; padding:20px; }
.message { text-align: center; margin: 20px; font-weight: bold; }
.error { color: red; }
.success { color: green; }
table { width: 80%; margin: 30px auto; border-collapse: collapse; background: #fff; }
th, td { border: 1px solid #ccc; padding: 10px; text-align: left; }
th { background: #00bcd4; color: white; }
a.button { display:inline-block; padding:10px 15px; margin:15px auto; background:#00bcd4; color:white; text-decoration:none; border-radius:6px; }
a.button:hover { background:#0195a3; }
footer { background:#2c3e50; color:white; text-align:center; padding:20px; margin-top:30px; }
</style>
</head>
<body>

<header><h1>Registered Users</h1></header>

<div class="message"><?= $message ?></div>

<a href="registration.html" class="button">← Go Back to Register</a>
<a href="users.csv" download class="button">Download CSV</a>

<table>
<tr>
<th>Username</th>
<th>Email</th>
<th>Contact</th>
</tr>

<?php
$result = $conn->query("SELECT username, email, contact FROM users ORDER BY id DESC");
if ($result->num_rows > 0) {
    while ($row = $result->fetch_assoc()) {
        echo "<tr>
                <td>{$row['username']}</td>
                <td>{$row['email']}</td>
                <td>{$row['contact']}</td>
              </tr>";
    }
} else {
    echo "<tr><td colspan='3' style='text-align:center;'>No registered users yet.</td></tr>";
}
$conn->close();
?>
</table>

<footer>
<p>&copy; 2025 Fitness Club. All rights reserved.</p>
</footer>

</body>
</html>
